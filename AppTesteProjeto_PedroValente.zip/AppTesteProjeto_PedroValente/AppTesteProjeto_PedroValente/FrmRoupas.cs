﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTesteProjeto_PedroValente
{
    public partial class FrmRoupas : Form
    {
        public FrmRoupas()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Resgatar valores da tela
            int qtdP = int.Parse(txtQtdP.Text);
            int qtdM = int.Parse(txtQtdM.Text);
            int qtdG = int.Parse(txtQtdG.Text);
            float resultado;

            //Calcular 
            resultado = qtdP * 12 + qtdM * 14 + qtdG * 22;

            //Mostrar resultado
            lblRs.Text = "R$" + resultado;


        }

        private void FrmRoupas_Load(object sender, EventArgs e)
        {

        }
    }
}
