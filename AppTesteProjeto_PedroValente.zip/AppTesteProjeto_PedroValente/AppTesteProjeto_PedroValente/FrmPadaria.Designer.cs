﻿namespace AppTesteProjeto_PedroValente
{
    partial class FrmPadaria
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPadaria));
            this.pnlTitulo = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblQtdPaes = new System.Windows.Forms.Label();
            this.lblQtdBroas = new System.Windows.Forms.Label();
            this.txtQtdPaes = new System.Windows.Forms.TextBox();
            this.txtQtdBroas = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.pnlPagar = new System.Windows.Forms.Panel();
            this.lblRs = new System.Windows.Forms.Label();
            this.lblValoraPagar = new System.Windows.Forms.Label();
            this.pnlTitulo.SuspendLayout();
            this.pnlPagar.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTitulo
            // 
            this.pnlTitulo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(34)))), ((int)(((byte)(38)))));
            this.pnlTitulo.Controls.Add(this.lblTitulo);
            this.pnlTitulo.Location = new System.Drawing.Point(1, 1);
            this.pnlTitulo.Name = "pnlTitulo";
            this.pnlTitulo.Size = new System.Drawing.Size(825, 123);
            this.pnlTitulo.TabIndex = 0;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Vladimir Script", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.Yellow;
            this.lblTitulo.Location = new System.Drawing.Point(243, 32);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(328, 58);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Padaria Cabulosa";
            // 
            // lblQtdPaes
            // 
            this.lblQtdPaes.AutoSize = true;
            this.lblQtdPaes.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdPaes.ForeColor = System.Drawing.Color.Black;
            this.lblQtdPaes.Location = new System.Drawing.Point(326, 153);
            this.lblQtdPaes.Name = "lblQtdPaes";
            this.lblQtdPaes.Size = new System.Drawing.Size(174, 25);
            this.lblQtdPaes.TabIndex = 1;
            this.lblQtdPaes.Text = "Quantidade de Pães";
            // 
            // lblQtdBroas
            // 
            this.lblQtdBroas.AutoSize = true;
            this.lblQtdBroas.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdBroas.ForeColor = System.Drawing.Color.Black;
            this.lblQtdBroas.Location = new System.Drawing.Point(326, 247);
            this.lblQtdBroas.Name = "lblQtdBroas";
            this.lblQtdBroas.Size = new System.Drawing.Size(180, 25);
            this.lblQtdBroas.TabIndex = 2;
            this.lblQtdBroas.Text = "Quantidade de Broas";
            // 
            // txtQtdPaes
            // 
            this.txtQtdPaes.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQtdPaes.Location = new System.Drawing.Point(322, 181);
            this.txtQtdPaes.Name = "txtQtdPaes";
            this.txtQtdPaes.Size = new System.Drawing.Size(189, 32);
            this.txtQtdPaes.TabIndex = 3;
            // 
            // txtQtdBroas
            // 
            this.txtQtdBroas.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQtdBroas.Location = new System.Drawing.Point(322, 275);
            this.txtQtdBroas.Name = "txtQtdBroas";
            this.txtQtdBroas.Size = new System.Drawing.Size(189, 32);
            this.txtQtdBroas.TabIndex = 4;
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(34)))), ((int)(((byte)(38)))));
            this.btnCalcular.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.ForeColor = System.Drawing.Color.Yellow;
            this.btnCalcular.Location = new System.Drawing.Point(367, 322);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(114, 42);
            this.btnCalcular.TabIndex = 5;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // pnlPagar
            // 
            this.pnlPagar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(34)))), ((int)(((byte)(38)))));
            this.pnlPagar.Controls.Add(this.lblRs);
            this.pnlPagar.Controls.Add(this.lblValoraPagar);
            this.pnlPagar.Location = new System.Drawing.Point(1, 411);
            this.pnlPagar.Name = "pnlPagar";
            this.pnlPagar.Size = new System.Drawing.Size(832, 100);
            this.pnlPagar.TabIndex = 6;
            // 
            // lblRs
            // 
            this.lblRs.AutoSize = true;
            this.lblRs.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRs.ForeColor = System.Drawing.Color.Yellow;
            this.lblRs.Location = new System.Drawing.Point(433, 33);
            this.lblRs.Name = "lblRs";
            this.lblRs.Size = new System.Drawing.Size(42, 31);
            this.lblRs.TabIndex = 1;
            this.lblRs.Text = "R$";
            // 
            // lblValoraPagar
            // 
            this.lblValoraPagar.AutoSize = true;
            this.lblValoraPagar.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValoraPagar.ForeColor = System.Drawing.Color.Yellow;
            this.lblValoraPagar.Location = new System.Drawing.Point(291, 33);
            this.lblValoraPagar.Name = "lblValoraPagar";
            this.lblValoraPagar.Size = new System.Drawing.Size(150, 31);
            this.lblValoraPagar.TabIndex = 0;
            this.lblValoraPagar.Text = "Valor a pagar:";
            // 
            // FrmPadaria
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(216)))), ((int)(((byte)(166)))));
            this.ClientSize = new System.Drawing.Size(825, 506);
            this.Controls.Add(this.pnlPagar);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtQtdBroas);
            this.Controls.Add(this.txtQtdPaes);
            this.Controls.Add(this.lblQtdBroas);
            this.Controls.Add(this.lblQtdPaes);
            this.Controls.Add(this.pnlTitulo);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmPadaria";
            this.Text = "Padaria Cabulosa";
            this.pnlTitulo.ResumeLayout(false);
            this.pnlTitulo.PerformLayout();
            this.pnlPagar.ResumeLayout(false);
            this.pnlPagar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlTitulo;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblQtdPaes;
        private System.Windows.Forms.Label lblQtdBroas;
        private System.Windows.Forms.TextBox txtQtdPaes;
        private System.Windows.Forms.TextBox txtQtdBroas;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Panel pnlPagar;
        private System.Windows.Forms.Label lblRs;
        private System.Windows.Forms.Label lblValoraPagar;
    }
}

