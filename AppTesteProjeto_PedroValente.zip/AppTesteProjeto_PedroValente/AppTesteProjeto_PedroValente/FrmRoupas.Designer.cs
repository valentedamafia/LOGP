﻿namespace AppTesteProjeto_PedroValente
{
    partial class FrmRoupas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmRoupas));
            this.lblTitulo = new System.Windows.Forms.Label();
            this.pnlTitulo = new System.Windows.Forms.Panel();
            this.lblQtdM = new System.Windows.Forms.Label();
            this.lblQtdG = new System.Windows.Forms.Label();
            this.lblQtdP = new System.Windows.Forms.Label();
            this.txtQtdG = new System.Windows.Forms.TextBox();
            this.txtQtdM = new System.Windows.Forms.TextBox();
            this.txtQtdP = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblValoraPagar = new System.Windows.Forms.Label();
            this.lblRs = new System.Windows.Forms.Label();
            this.pnlTitulo.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Broadway", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(342, 24);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(149, 42);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Roupa";
            // 
            // pnlTitulo
            // 
            this.pnlTitulo.BackColor = System.Drawing.Color.White;
            this.pnlTitulo.Controls.Add(this.lblTitulo);
            this.pnlTitulo.Location = new System.Drawing.Point(-2, -3);
            this.pnlTitulo.Name = "pnlTitulo";
            this.pnlTitulo.Size = new System.Drawing.Size(804, 91);
            this.pnlTitulo.TabIndex = 1;
            this.pnlTitulo.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // lblQtdM
            // 
            this.lblQtdM.AutoSize = true;
            this.lblQtdM.BackColor = System.Drawing.Color.Black;
            this.lblQtdM.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdM.ForeColor = System.Drawing.Color.White;
            this.lblQtdM.Location = new System.Drawing.Point(297, 147);
            this.lblQtdM.Name = "lblQtdM";
            this.lblQtdM.Size = new System.Drawing.Size(219, 25);
            this.lblQtdM.TabIndex = 2;
            this.lblQtdM.Text = "Quantidade de camisas M";
            // 
            // lblQtdG
            // 
            this.lblQtdG.AutoSize = true;
            this.lblQtdG.BackColor = System.Drawing.Color.Black;
            this.lblQtdG.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdG.ForeColor = System.Drawing.Color.White;
            this.lblQtdG.Location = new System.Drawing.Point(552, 147);
            this.lblQtdG.Name = "lblQtdG";
            this.lblQtdG.Size = new System.Drawing.Size(217, 25);
            this.lblQtdG.TabIndex = 3;
            this.lblQtdG.Text = "Quantidade de camisas G";
            // 
            // lblQtdP
            // 
            this.lblQtdP.AutoSize = true;
            this.lblQtdP.BackColor = System.Drawing.Color.Black;
            this.lblQtdP.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdP.ForeColor = System.Drawing.Color.White;
            this.lblQtdP.Location = new System.Drawing.Point(38, 147);
            this.lblQtdP.Name = "lblQtdP";
            this.lblQtdP.Size = new System.Drawing.Size(215, 25);
            this.lblQtdP.TabIndex = 4;
            this.lblQtdP.Text = "Quantidade de camisas P";
            // 
            // txtQtdG
            // 
            this.txtQtdG.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQtdG.Location = new System.Drawing.Point(592, 186);
            this.txtQtdG.Name = "txtQtdG";
            this.txtQtdG.Size = new System.Drawing.Size(153, 31);
            this.txtQtdG.TabIndex = 5;
            // 
            // txtQtdM
            // 
            this.txtQtdM.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQtdM.Location = new System.Drawing.Point(336, 186);
            this.txtQtdM.Name = "txtQtdM";
            this.txtQtdM.Size = new System.Drawing.Size(153, 31);
            this.txtQtdM.TabIndex = 6;
            // 
            // txtQtdP
            // 
            this.txtQtdP.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQtdP.Location = new System.Drawing.Point(70, 186);
            this.txtQtdP.Name = "txtQtdP";
            this.txtQtdP.Size = new System.Drawing.Size(153, 31);
            this.txtQtdP.TabIndex = 7;
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.White;
            this.btnCalcular.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(359, 266);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(113, 34);
            this.btnCalcular.TabIndex = 8;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblValoraPagar
            // 
            this.lblValoraPagar.AutoSize = true;
            this.lblValoraPagar.Font = new System.Drawing.Font("Arial Narrow", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValoraPagar.ForeColor = System.Drawing.Color.White;
            this.lblValoraPagar.Location = new System.Drawing.Point(251, 378);
            this.lblValoraPagar.Name = "lblValoraPagar";
            this.lblValoraPagar.Size = new System.Drawing.Size(175, 33);
            this.lblValoraPagar.TabIndex = 9;
            this.lblValoraPagar.Text = "Valor a pagar:";
            // 
            // lblRs
            // 
            this.lblRs.AutoSize = true;
            this.lblRs.Font = new System.Drawing.Font("Arial Narrow", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRs.ForeColor = System.Drawing.Color.White;
            this.lblRs.Location = new System.Drawing.Point(421, 378);
            this.lblRs.Name = "lblRs";
            this.lblRs.Size = new System.Drawing.Size(45, 33);
            this.lblRs.TabIndex = 10;
            this.lblRs.Text = "R$";
            // 
            // FrmRoupas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblRs);
            this.Controls.Add(this.lblValoraPagar);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtQtdP);
            this.Controls.Add(this.txtQtdM);
            this.Controls.Add(this.txtQtdG);
            this.Controls.Add(this.lblQtdP);
            this.Controls.Add(this.lblQtdG);
            this.Controls.Add(this.lblQtdM);
            this.Controls.Add(this.pnlTitulo);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmRoupas";
            this.Text = "Roupa";
            this.Load += new System.EventHandler(this.FrmRoupas_Load);
            this.pnlTitulo.ResumeLayout(false);
            this.pnlTitulo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Panel pnlTitulo;
        private System.Windows.Forms.Label lblQtdM;
        private System.Windows.Forms.Label lblQtdG;
        private System.Windows.Forms.Label lblQtdP;
        private System.Windows.Forms.TextBox txtQtdG;
        private System.Windows.Forms.TextBox txtQtdM;
        private System.Windows.Forms.TextBox txtQtdP;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblValoraPagar;
        private System.Windows.Forms.Label lblRs;
    }
}