﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTesteProjeto_PedroValente
{
    public partial class FrmPadaria : Form
    {
        public FrmPadaria()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Pegar Valores da tela
            int qtdPaes = int.Parse(txtQtdPaes.Text);
            int qtdBroas = int.Parse(txtQtdBroas.Text);
            float total;

            //Calcular 
            total = qtdBroas * 1.50f + qtdPaes * 0.12f;

            //Mostrar Resultado
            lblRs.Text = "R$" + total;
        }
    }
}
