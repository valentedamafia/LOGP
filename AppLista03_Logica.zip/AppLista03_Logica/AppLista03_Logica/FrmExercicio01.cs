﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Logica
{
    public partial class FrmExercicio01 : Form
    {
        public FrmExercicio01()
        {
            InitializeComponent();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {

           //capturando dados

            float num1 = float.Parse(txtNum1.Text);
            float num3 = float.Parse(txtNum3.Text);
            float soma;

          //realizar soma

            soma = num1 + num3;

          //mostrar resultado

            MessageBox.Show("Soma = " + soma);



        }   
            
    }
}
