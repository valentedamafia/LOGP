﻿namespace Atividadelista
{
    partial class frmcal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtinteiro = new System.Windows.Forms.TextBox();
            this.txtdecimal = new System.Windows.Forms.TextBox();
            this.lblint = new System.Windows.Forms.Label();
            this.lbldecimal = new System.Windows.Forms.Label();
            this.btnresult = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtinteiro
            // 
            this.txtinteiro.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtinteiro.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinteiro.Location = new System.Drawing.Point(44, 43);
            this.txtinteiro.Name = "txtinteiro";
            this.txtinteiro.Size = new System.Drawing.Size(191, 29);
            this.txtinteiro.TabIndex = 0;
            // 
            // txtdecimal
            // 
            this.txtdecimal.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtdecimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdecimal.Location = new System.Drawing.Point(44, 110);
            this.txtdecimal.Name = "txtdecimal";
            this.txtdecimal.Size = new System.Drawing.Size(191, 29);
            this.txtdecimal.TabIndex = 1;
            // 
            // lblint
            // 
            this.lblint.AutoSize = true;
            this.lblint.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblint.ForeColor = System.Drawing.Color.White;
            this.lblint.Location = new System.Drawing.Point(102, 24);
            this.lblint.Name = "lblint";
            this.lblint.Size = new System.Drawing.Size(43, 16);
            this.lblint.TabIndex = 5;
            this.lblint.Text = "Inteiro";
            this.lblint.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbldecimal
            // 
            this.lbldecimal.AutoSize = true;
            this.lbldecimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldecimal.ForeColor = System.Drawing.Color.White;
            this.lbldecimal.Location = new System.Drawing.Point(102, 91);
            this.lbldecimal.Name = "lbldecimal";
            this.lbldecimal.Size = new System.Drawing.Size(57, 16);
            this.lbldecimal.TabIndex = 6;
            this.lbldecimal.Text = "Decimal";
            // 
            // btnresult
            // 
            this.btnresult.Location = new System.Drawing.Point(95, 193);
            this.btnresult.Name = "btnresult";
            this.btnresult.Size = new System.Drawing.Size(75, 23);
            this.btnresult.TabIndex = 7;
            this.btnresult.Text = "=";
            this.btnresult.UseVisualStyleBackColor = true;
            this.btnresult.Click += new System.EventHandler(this.btnresult_Click);
            // 
            // frmcal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(280, 286);
            this.Controls.Add(this.btnresult);
            this.Controls.Add(this.lbldecimal);
            this.Controls.Add(this.lblint);
            this.Controls.Add(this.txtdecimal);
            this.Controls.Add(this.txtinteiro);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "frmcal";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtinteiro;
        private System.Windows.Forms.TextBox txtdecimal;
        private System.Windows.Forms.Label lblint;
        private System.Windows.Forms.Label lbldecimal;
        private System.Windows.Forms.Button btnresult;
    }
}

