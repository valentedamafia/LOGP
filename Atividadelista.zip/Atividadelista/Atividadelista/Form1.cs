﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividadelista
{
    public partial class frmcal : Form
    {
        public frmcal()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        

        

       

        private void btnresult_Click(object sender, EventArgs e)
        {
            int varInt = int.Parse(txtinteiro.Text);
            float varDecimal = float.Parse(txtdecimal.Text);
            float resultado;


            //Soma;
            resultado = varInt + varDecimal;
            MessageBox.Show("Soma: " + resultado);

            //Subtração;
            resultado = varInt - varDecimal;
            MessageBox.Show("Subtração: " + resultado);

            //Divisão;
            resultado = varInt / varDecimal;
            MessageBox.Show("Divisão: " + resultado);

            //Multiplicação
            resultado = varInt * varDecimal;
            MessageBox.Show("Multiplicação: " + resultado);
        }








